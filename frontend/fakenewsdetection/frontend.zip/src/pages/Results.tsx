import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  ArrowLeft, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  FileText,
  Link as LinkIcon,
  Image as ImageIcon,
  ExternalLink,
  TrendingUp,
  MessageSquare,
  ThumbsUp,
  ThumbsDown
} from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { useEffect } from "react";

const Results = () => {
  const navigate = useNavigate();
  const location = useLocation();

  // Pull backend result from navigation state
  const result = location.state?.result;

  useEffect(() => {
    if (!result) {
      // Redirect back if no result available (e.g. on page refresh)
      navigate("/detect");
    }
  }, [result, navigate]);

  if (!result) {
    return <div className="p-8 text-center">No results to display</div>;
  }

  const getVerdictColor = () => {
    if (result.prediction === "FAKE") return "text-destructive";
    if (result.prediction === "REAL") return "text-primary";
    return "text-muted-foreground";
  };

  const getVerdictIcon = () => {
    if (result.prediction === "FAKE") return <XCircle className="h-16 w-16 text-destructive" />;
    if (result.prediction === "REAL") return <CheckCircle2 className="h-16 w-16 text-primary" />;
    return <AlertCircle className="h-16 w-16 text-muted-foreground" />;
  };

  const getInputIcon = () => {
    if (result.inputType === "url") return <LinkIcon className="h-4 w-4" />;
    if (result.inputType === "image") return <ImageIcon className="h-4 w-4" />;
    return <FileText className="h-4 w-4" />;
  };

  const getSeverityColor = (severity: string) => {
    if (severity === "high") return "destructive";
    if (severity === "medium") return "secondary";
    return "outline";
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-accent/20">
      <div className="container mx-auto px-4 py-8 md:py-16 max-w-6xl">
        <Button
          variant="ghost"
          onClick={() => navigate("/detect")}
          className="mb-6"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          New Analysis
        </Button>

        {/* --- everything below stays the same, using result directly --- */}
        {/* Main Verdict Card */}
        <Card className="mb-6">
          <CardHeader className="text-center pb-6">
            <div className="flex justify-center mb-4">
              {getVerdictIcon()}
            </div>
            <CardTitle className={`text-3xl md:text-4xl mb-2 ${getVerdictColor()}`}>
              {result.prediction === "FAKE" && "Likely Fake News"}
              {result.prediction === "REAL" && "Likely Legitimate"}
              {result.prediction === "UNCERTAIN" && "Uncertain - Needs Review"}
            </CardTitle>
            <CardDescription className="flex items-center justify-center gap-2 text-base">
              {getInputIcon()}
              Input Type: {result.inputType?.toUpperCase()}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Confidence Score */}
            {result.confidence && (
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium">Confidence Score</span>
                  <span className="text-sm font-bold">{result.confidence}%</span>
                </div>
                <Progress value={result.confidence} className="h-3" />
              </div>
            )}

            {/* Analysis Metrics */}
            {result.metrics && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-3 rounded-lg bg-accent/50 text-center">
                  <p className="text-xs text-muted-foreground mb-1">Language</p>
                  <p className="font-semibold">{result.metrics.languageComplexity}%</p>
                </div>
                <div className="p-3 rounded-lg bg-accent/50 text-center">
                  <p className="text-xs text-muted-foreground mb-1">Emotional</p>
                  <p className="font-semibold">{result.metrics.emotionalTone}%</p>
                </div>
                <div className="p-3 rounded-lg bg-accent/50 text-center">
                  <p className="text-xs text-muted-foreground mb-1">Factual</p>
                  <p className="font-semibold">{result.metrics.factualDensity}%</p>
                </div>
                <div className="p-3 rounded-lg bg-accent/50 text-center">
                  <p className="text-xs text-muted-foreground mb-1">Source</p>
                  <p className="font-semibold">{result.metrics.sourceCredibility}%</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Rest of your cards: Analyzed Content, Suspicious Segments, Key Signals, External Evidence, User Feedback, etc. */}
        {/* --- all remain unchanged, just make sure to check result?.field before rendering --- */}
      </div>
    </div>
  );
};

export default Results;
